@extends('layouts.back-end.app-seller')

@section('title', 'خدماتي المُسنَدة للعقارات')

@push('css_or_js')
<style>
/* ═══════════════════════════════════════
   VARIABLES
═══════════════════════════════════════ */
:root {
    --navy:        #0b1628;
    --navy-2:      #132035;
    --navy-3:      #1c2f4a;
    --gold:        #c9974a;
    --gold-light:  #e8b96a;
    --gold-pale:   #fef3df;
    --accent:      #2563eb;
    --success:     #10b981;
    --warning:     #f59e0b;
    --danger:      #ef4444;
    --info:        #06b6d4;
    --purple:      #7c3aed;
    --surface:     #ffffff;
    --surface-2:   #f8fafc;
    --border:      #e5eaf2;
    --text:        #0b1628;
    --muted:       #64748b;
    --radius:      20px;
    --radius-sm:   12px;
    --shadow:      0 4px 20px rgba(11,22,40,.07);
    --shadow-lg:   0 16px 48px rgba(11,22,40,.14);
    --shadow-xl:   0 32px 80px rgba(11,22,40,.22);
}

/* ═══════════════════════════════════════
   BASE
═══════════════════════════════════════ */
body { background: #f0f4f9 !important; }
.offers-page { padding-bottom: 40px; }

/* ═══════════════════════════════════════
   HERO HEADER
═══════════════════════════════════════ */
.page-hero {
    background: var(--navy);
    border-radius: 26px;
    padding: 28px 32px;
    margin-bottom: 24px;
    position: relative;
    overflow: hidden;
}
.page-hero::before {
    content: '';
    position: absolute;
    top: -70px; right: -70px;
    width: 240px; height: 240px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(201,151,74,.15) 0%, transparent 70%);
    pointer-events: none;
}
.page-hero::after {
    content: '';
    position: absolute;
    bottom: -50px; left: 80px;
    width: 180px; height: 180px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(37,99,235,.1) 0%, transparent 70%);
    pointer-events: none;
}
.hero-inner { position: relative; z-index: 1; }
.hero-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(201,151,74,.15);
    border: 1px solid rgba(201,151,74,.3);
    color: var(--gold-light);
    border-radius: 999px;
    padding: 5px 14px;
    font-size: 12px;
    font-weight: 700;
    margin-bottom: 12px;
}
.hero-title {
    font-size: 26px;
    font-weight: 900;
    color: #fff;
    margin-bottom: 6px;
}
.hero-subtitle {
    font-size: 14px;
    color: rgba(255,255,255,.55);
    margin-bottom: 0;
}
.hero-stats {
    display: flex;
    gap: 16px;
    flex-wrap: wrap;
    margin-top: 20px;
}
.hero-stat {
    background: rgba(255,255,255,.06);
    border: 1px solid rgba(255,255,255,.1);
    border-radius: 14px;
    padding: 12px 18px;
    text-align: center;
    min-width: 90px;
}
.hero-stat-num {
    font-size: 22px;
    font-weight: 900;
    color: #fff;
    display: block;
    line-height: 1;
}
.hero-stat-label {
    font-size: 11px;
    color: rgba(255,255,255,.45);
    font-weight: 600;
    margin-top: 4px;
    display: block;
}
.hero-action {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: linear-gradient(135deg, var(--accent), var(--purple));
    color: #fff;
    border: none;
    border-radius: 14px;
    padding: 11px 22px;
    font-size: 13px;
    font-weight: 800;
    cursor: pointer;
    text-decoration: none;
    transition: all .2s;
    box-shadow: 0 8px 20px rgba(37,99,235,.3);
}
.hero-action:hover {
    color: #fff;
    transform: translateY(-2px);
    box-shadow: 0 12px 28px rgba(37,99,235,.38);
    text-decoration: none;
}
.hero-action svg { width: 16px; height: 16px; }

/* ═══════════════════════════════════════
   FILTER BAR
═══════════════════════════════════════ */
.filter-bar {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 18px;
    padding: 14px 18px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
    box-shadow: var(--shadow);
}
.filter-search {
    flex: 1;
    min-width: 200px;
    display: flex;
    align-items: center;
    gap: 10px;
    background: var(--surface-2);
    border: 1.5px solid var(--border);
    border-radius: 12px;
    padding: 9px 14px;
}
.filter-search svg { width: 16px; height: 16px; color: var(--muted); flex-shrink: 0; }
.filter-search input {
    border: none;
    background: none;
    outline: none;
    font-size: 13px;
    font-weight: 600;
    color: var(--text);
    width: 100%;
}
.filter-chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 16px;
    border-radius: 10px;
    border: 1.5px solid var(--border);
    background: var(--surface);
    font-size: 12px;
    font-weight: 700;
    color: var(--muted);
    cursor: pointer;
    transition: all .18s;
    user-select: none;
}
.filter-chip:hover { border-color: rgba(37,99,235,.3); color: var(--accent); background: #eff6ff; }
.filter-chip.active { background: var(--navy); border-color: var(--navy); color: #fff; }

/* ═══════════════════════════════════════
   GRID — DESKTOP CARDS
═══════════════════════════════════════ */
.offers-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
    gap: 18px;
}

.offer-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
    overflow: hidden;
    cursor: pointer;
    transition: all .25s;
    position: relative;
}
.offer-card:hover {
    transform: translateY(-6px);
    box-shadow: var(--shadow-lg);
    border-color: rgba(37,99,235,.2);
}
.offer-card:hover .card-arrow { transform: translateX(-4px); }

/* card image */
.card-img-wrap {
    position: relative;
    height: 180px;
    overflow: hidden;
    background: var(--surface-2);
}
.card-img-wrap img {
    width: 100%; height: 100%;
    object-fit: cover;
    transition: transform .4s;
}
.offer-card:hover .card-img-wrap img { transform: scale(1.05); }

.card-img-overlay {
    position: absolute;
    inset: 0;
    background: linear-gradient(to top, rgba(11,22,40,.7) 0%, transparent 60%);
}
.card-badges {
    position: absolute;
    top: 12px;
    left: 12px;
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
}
.card-badge {
    padding: 4px 10px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 800;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    backdrop-filter: blur(6px);
}
.card-badge.status-active   { background: rgba(16,185,129,.85); color: #fff; }
.card-badge.status-expired  { background: rgba(239,68,68,.85); color: #fff; }
.card-badge.status-pending  { background: rgba(245,158,11,.85); color: #fff; }
.card-badge.status-cancelled{ background: rgba(100,116,139,.85); color: #fff; }
.card-badge.pay-paid   { background: rgba(16,185,129,.85); color: #fff; }
.card-badge.pay-unpaid { background: rgba(239,68,68,.85); color: #fff; }

.card-offer-type {
    position: absolute;
    bottom: 12px;
    right: 12px;
    background: var(--navy);
    color: var(--gold-light);
    border-radius: 10px;
    padding: 5px 12px;
    font-size: 12px;
    font-weight: 800;
}

/* card body */
.card-body-inner { padding: 18px; }
.card-offer-title {
    font-size: 17px;
    font-weight: 900;
    color: var(--text);
    margin-bottom: 6px;
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 8px;
}
.card-arrow {
    width: 28px; height: 28px;
    background: var(--surface-2);
    border: 1px solid var(--border);
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    transition: transform .25s;
}
.card-arrow svg { width: 14px; height: 14px; color: var(--muted); }

.card-service-name {
    font-size: 13px;
    color: var(--muted);
    font-weight: 600;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    gap: 6px;
}
.card-service-name svg { width: 13px; height: 13px; color: var(--accent); }

.card-tags { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 14px; }
.card-tag {
    background: #eff6ff;
    border: 1px solid #bfdbfe;
    color: #1d4ed8;
    border-radius: 8px;
    padding: 3px 10px;
    font-size: 11px;
    font-weight: 700;
}
.card-tag.zone {
    background: #f0fdf4;
    border-color: #bbf7d0;
    color: #15803d;
}

.card-meta {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-top: 12px;
    border-top: 1px solid var(--border);
}
.card-plan {
    font-size: 13px;
    font-weight: 800;
    color: var(--navy);
    display: flex;
    align-items: center;
    gap: 6px;
}
.card-plan svg { width: 14px; height: 14px; color: var(--gold); }
.card-expiry {
    font-size: 12px;
    color: var(--muted);
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 5px;
}
.card-expiry svg { width: 12px; height: 12px; }

/* ═══════════════════════════════════════
   MODAL OVERLAY
═══════════════════════════════════════ */
.detail-overlay {
    position: fixed;
    inset: 0;
    background: rgba(11,22,40,.6);
    backdrop-filter: blur(8px);
    z-index: 9999;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
    opacity: 0;
    pointer-events: none;
    transition: opacity .3s;
}
.detail-overlay.open {
    opacity: 1;
    pointer-events: all;
}
.detail-overlay.open .detail-sheet {
    transform: translateY(0) scale(1);
    opacity: 1;
}

.detail-sheet {
    background: var(--surface);
    border-radius: 28px;
    width: 100%;
    max-width: 720px;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: var(--shadow-xl);
    transform: translateY(30px) scale(.97);
    opacity: 0;
    transition: all .35s cubic-bezier(.34,1.36,.64,1);
    position: relative;
}
.detail-sheet::-webkit-scrollbar { width: 0; }

/* modal header image */
.modal-img-wrap {
    position: relative;
    height: 260px;
    overflow: hidden;
    border-radius: 28px 28px 0 0;
}
.modal-img-wrap img {
    width: 100%; height: 100%;
    object-fit: cover;
}
.modal-img-gradient {
    position: absolute;
    inset: 0;
    background: linear-gradient(to top, var(--navy) 0%, transparent 55%);
}
.modal-img-title {
    position: absolute;
    bottom: 20px;
    right: 22px;
    left: 22px;
}
.modal-img-title h2 {
    font-size: 24px;
    font-weight: 900;
    color: #fff;
    margin-bottom: 6px;
}
.modal-img-title .modal-img-service {
    color: rgba(255,255,255,.7);
    font-size: 14px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 6px;
}
.modal-img-badges {
    position: absolute;
    top: 16px;
    left: 16px;
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}
.modal-close {
    position: absolute;
    top: 16px;
    right: 16px;
    width: 38px; height: 38px;
    background: rgba(255,255,255,.2);
    backdrop-filter: blur(6px);
    border: 1px solid rgba(255,255,255,.25);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all .2s;
    z-index: 2;
}
.modal-close:hover { background: rgba(239,68,68,.75); border-color: transparent; }
.modal-close svg { width: 16px; height: 16px; color: #fff; }

/* modal body */
.modal-body-inner { padding: 24px; }

.modal-section-title {
    font-size: 12px;
    font-weight: 800;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: .07em;
    margin-bottom: 14px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.modal-section-title::after {
    content: '';
    flex: 1;
    height: 1px;
    background: var(--border);
}

.info-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 12px;
    margin-bottom: 22px;
}
.info-item {
    background: var(--surface-2);
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 14px;
}
.info-item-label {
    font-size: 11px;
    color: var(--muted);
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .04em;
    margin-bottom: 6px;
    display: flex;
    align-items: center;
    gap: 5px;
}
.info-item-label svg { width: 12px; height: 12px; }
.info-item-val {
    font-size: 16px;
    font-weight: 900;
    color: var(--text);
}
.info-item-val.price-val { color: var(--accent); }
.info-item-val.green-val { color: var(--success); }
.info-item-val.red-val   { color: var(--danger); }
.info-item-val.gold-val  { color: var(--gold); }

.tags-section { margin-bottom: 22px; }
.tag-group-label {
    font-size: 13px;
    font-weight: 800;
    color: var(--text);
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 6px;
}
.tag-group-label svg { width: 15px; height: 15px; color: var(--accent); }
.tag-pills { display: flex; flex-wrap: wrap; gap: 8px; }
.tag-pill {
    padding: 7px 14px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 5px;
}
.tag-pill.cat { background: #eff6ff; border: 1px solid #bfdbfe; color: #1d4ed8; }
.tag-pill.zon { background: #f0fdf4; border: 1px solid #bbf7d0; color: #15803d; }
.tag-pill svg { width: 12px; height: 12px; }

.plan-card-modal {
    background: var(--navy);
    border-radius: 18px;
    padding: 18px;
    margin-bottom: 22px;
    display: flex;
    align-items: center;
    gap: 14px;
}
.plan-icon {
    width: 48px; height: 48px;
    border-radius: 14px;
    background: rgba(201,151,74,.15);
    border: 1px solid rgba(201,151,74,.25);
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
}
.plan-icon svg { width: 22px; height: 22px; color: var(--gold-light); }
.plan-info { flex: 1; }
.plan-info-name {
    font-size: 16px;
    font-weight: 900;
    color: #fff;
    margin-bottom: 4px;
}
.plan-info-price {
    font-size: 13px;
    color: rgba(255,255,255,.5);
    font-weight: 600;
}
.plan-price-big {
    font-size: 26px;
    font-weight: 900;
    color: #38bdf8;
    line-height: 1;
}
.plan-price-cur {
    font-size: 12px;
    color: rgba(255,255,255,.45);
    font-weight: 600;
}

.modal-actions {
    display: flex;
    gap: 10px;
    padding-top: 16px;
    border-top: 1px solid var(--border);
}
.btn-modal-view {
    flex: 1;
    background: var(--navy);
    color: #fff;
    border: none;
    border-radius: 14px;
    padding: 13px;
    font-size: 14px;
    font-weight: 800;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    cursor: pointer;
    text-decoration: none;
    transition: all .2s;
}
.btn-modal-view:hover {
    background: var(--navy-3);
    color: #fff;
    text-decoration: none;
    transform: translateY(-2px);
}
.btn-modal-view svg { width: 16px; height: 16px; }
.btn-modal-pay {
    flex: 1;
    background: linear-gradient(135deg, #059669, #10b981);
    color: #fff;
    border: none;
    border-radius: 14px;
    padding: 13px;
    font-size: 14px;
    font-weight: 800;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    cursor: pointer;
    text-decoration: none;
    transition: all .2s;
}
.btn-modal-pay:hover {
    color: #fff;
    text-decoration: none;
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(16,185,129,.3);
}
.btn-modal-pay svg { width: 16px; height: 16px; }

/* ═══════════════════════════════════════
   EMPTY STATE
═══════════════════════════════════════ */
.empty-state {
    text-align: center;
    padding: 80px 20px;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
}
.empty-icon {
    width: 72px; height: 72px;
    background: var(--surface-2);
    border: 1px solid var(--border);
    border-radius: 22px;
    display: flex; align-items: center; justify-content: center;
    margin: 0 auto 18px;
}
.empty-icon svg { width: 32px; height: 32px; color: var(--muted); }
.empty-title { font-size: 18px; font-weight: 900; color: var(--text); margin-bottom: 8px; }
.empty-text  { font-size: 14px; color: var(--muted); margin-bottom: 24px; }

/* ═══════════════════════════════════════
   MOBILE — APP STYLE
═══════════════════════════════════════ */
@media (max-width: 767.98px) {
    .offers-page { padding-bottom: 20px; }
    .page-hero { border-radius: 20px; padding: 20px; }
    .hero-title { font-size: 20px; }
    .hero-stats { gap: 10px; }
    .hero-stat { padding: 10px 14px; min-width: 76px; }
    .hero-stat-num { font-size: 18px; }

    .offers-grid { grid-template-columns: 1fr; gap: 14px; }

    .offer-card { border-radius: 18px; }
    .card-img-wrap { height: 160px; }

    /* bottom sheet on mobile */
    .detail-overlay {
        align-items: flex-end;
        padding: 0;
    }
    .detail-sheet {
        border-radius: 28px 28px 0 0;
        max-width: 100%;
        max-height: 92vh;
        transform: translateY(100%);
    }
    .detail-overlay.open .detail-sheet {
        transform: translateY(0);
    }
    .modal-img-wrap { border-radius: 28px 28px 0 0; height: 220px; }
    .modal-body-inner { padding: 18px; }
    .info-grid { grid-template-columns: 1fr 1fr; gap: 10px; }
    .modal-actions { flex-direction: column; }
    .plan-card-modal { flex-direction: column; align-items: flex-start; }

    /* drag handle */
    .sheet-handle {
        width: 40px; height: 4px;
        background: var(--border);
        border-radius: 999px;
        margin: 12px auto 0;
        display: block;
    }

    .filter-bar { border-radius: 14px; }
}

@media (min-width: 768px) {
    .sheet-handle { display: none; }
}

/* ═══════════════════════════════════════
   SCROLL ANIMATION
═══════════════════════════════════════ */
.offer-card {
    animation: cardIn .4s both;
}
@keyframes cardIn {
    from { opacity: 0; transform: translateY(20px); }
    to   { opacity: 1; transform: translateY(0); }
}
</style>
@endpush

@section('content')
<div class="content container-fluid offers-page">

    {{-- ══ HERO ══════════════════════════════════════════════ --}}
    <div class="page-hero">
        <div class="hero-inner">
            <div class="d-flex align-items-start justify-content-between flex-wrap gap-3">
                <div>
                    <div class="hero-eyebrow">
                        <svg width="13" height="13" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"/>
                        </svg>
                        لوحة الخدمات
                    </div>
                    <h1 class="hero-title">خدماتي المُسنَدة للعقارات</h1>
                    <p class="hero-subtitle">جميع عروضك الإعلانية المرتبطة بالعقارات في مكان واحد</p>

                    <div class="hero-stats">
                        <div class="hero-stat">
                            <span class="hero-stat-num" id="stat-total">{{ $offers->count() }}</span>
                            <span class="hero-stat-label">إجمالي العروض</span>
                        </div>
                        <div class="hero-stat">
                            <span class="hero-stat-num" id="stat-active">
                                {{ $offers->filter(fn($o) => optional(optional($o->serviceProviders->first())->subscriptions->first())->subscription_status === 'active')->count() }}
                            </span>
                            <span class="hero-stat-label">نشطة</span>
                        </div>
                        <div class="hero-stat">
                            <span class="hero-stat-num" id="stat-unpaid">
                                {{ $offers->filter(fn($o) => optional(optional($o->serviceProviders->first())->subscriptions->first())->payment_status !== 'paid')->count() }}
                            </span>
                            <span class="hero-stat-label">غير مدفوع</span>
                        </div>
                    </div>
                </div>

                <a href="{{ route('service-provider.estaes.create-offer') }}" class="hero-action">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                        <path d="M12 4v16m8-8H4"/>
                    </svg>
                    إضافة خدمة جديدة
                </a>
            </div>
        </div>
    </div>

    {{-- ══ FILTER BAR ════════════════════════════════════════ --}}
    <div class="filter-bar">
        <div class="filter-search">
            <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
            </svg>
            <input type="text" id="search-input" placeholder="ابحث عن عرض...">
        </div>
        <div class="filter-chip active" data-filter="all">الكل</div>
        <div class="filter-chip" data-filter="active">نشطة</div>
        <div class="filter-chip" data-filter="expired">منتهية</div>
        <div class="filter-chip" data-filter="unpaid">غير مدفوعة</div>
    </div>

    {{-- ══ GRID ══════════════════════════════════════════════ --}}
    @if($offers->isEmpty())
        <div class="empty-state">
            <div class="empty-icon">
                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                    <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                </svg>
            </div>
            <h3 class="empty-title">لا توجد خدمات مُسنَدة</h3>
            <p class="empty-text">لم تقم بإضافة أي خدمة لعقاراتك بعد، ابدأ الآن!</p>
            <a href="{{ route('service-provider.estaes.create-offer') }}" class="hero-action" style="display:inline-flex;">
                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path d="M12 4v16m8-8H4"/></svg>
                إضافة أول خدمة
            </a>
        </div>
    @else
        <div class="offers-grid" id="offers-grid">
            @foreach ($offers as $index => $estate)
                @php
                    $subscription = $estate->serviceProviders
                        ->first()
                        ?->subscriptions()
                        ->where('offer_id', $estate->id)
                        ->first();

                    $subStatus   = $subscription?->subscription_status ?? 'none';
                    $payStatus   = $subscription?->payment_status ?? 'none';
                    $planName    = $subscription?->servicePlan?->name ?? '—';
                    $planPrice   = number_format($subscription?->servicePlan?->price ?? 0, 2);
                    $isPaid      = $payStatus === 'paid';
                    $isActive    = $subStatus === 'active';

                    $statusMap = [
                        'active'    => ['label' => 'نشط',    'cls' => 'active'],
                        'expired'   => ['label' => 'منتهي',  'cls' => 'expired'],
                        'pending'   => ['label' => 'معلق',   'cls' => 'pending'],
                        'cancelled' => ['label' => 'ملغى',   'cls' => 'cancelled'],
                        'none'      => ['label' => 'غير مشترك','cls'=>'cancelled'],
                    ];
                    $statusInfo = $statusMap[$subStatus] ?? ['label' => $subStatus, 'cls' => 'pending'];

                    $paymentRoute = $subscription ? route('service-provider.estaes.payment', [
                        'offer_id'            => $estate->id,
                        'price'               => $subscription->servicePlan?->price ?? 0,
                        'subscription_number' => $subscription->id,
                    ]) : '#';

                    $viewRoute = route('service-provider.offers.display', $estate->id);
                    $imgSrc    = asset('storage/app/public/' . $estate->image);

                    $catNames  = $estate->categories->pluck('name_ar')->implode('،');
                    $zoneNames = $estate->zones->pluck('name_ar')->implode('،');

                    $catNamesJson  = json_encode($estate->categories->pluck('name_ar'));
                    $zoneNamesJson = json_encode($estate->zones->pluck('name_ar'));
                @endphp

                <div class="offer-card"
                     style="animation-delay: {{ $index * 0.06 }}s"
                     data-status="{{ $subStatus }}"
                     data-payment="{{ $payStatus }}"
                     onclick="openModal({
                         title:       {{ json_encode($estate->title) }},
                         service:     {{ json_encode($estate->serviceType?->name ?? '') }},
                         offerType:   {{ json_encode($estate->offer_type) }},
                         price:       {{ json_encode($estate->service_price) }},
                         discount:    {{ json_encode($estate->discount) }},
                         img:         {{ json_encode($imgSrc) }},
                         categories:  {{ $catNamesJson }},
                         zones:       {{ $zoneNamesJson }},
                         expiry:      {{ json_encode($estate->expiry_date) }},
                         planName:    {{ json_encode($planName) }},
                         planPrice:   {{ json_encode($planPrice) }},
                         subStatus:   {{ json_encode($statusInfo['label']) }},
                         subCls:      {{ json_encode($statusInfo['cls']) }},
                         payStatus:   {{ json_encode($isPaid ? 'مدفوع' : 'غير مدفوع') }},
                         paid:        {{ $isPaid ? 'true' : 'false' }},
                         viewRoute:   {{ json_encode($viewRoute) }},
                         payRoute:    {{ json_encode($paymentRoute) }}
                     })">

                    {{-- Card Image --}}
                    <div class="card-img-wrap">
                        <img src="{{ $imgSrc }}" alt="{{ $estate->title }}"
                             onerror="this.src='{{ asset('public/assets/images/default-estate.jpg') }}'">
                        <div class="card-img-overlay"></div>

                        <div class="card-badges">
                            <span class="card-badge status-{{ $statusInfo['cls'] }}">
                                <svg width="8" height="8" viewBox="0 0 8 8" fill="currentColor"><circle cx="4" cy="4" r="4"/></svg>
                                {{ $statusInfo['label'] }}
                            </span>
                            <span class="card-badge {{ $isPaid ? 'pay-paid' : 'pay-unpaid' }}">
                                {{ $isPaid ? 'مدفوع' : 'غير مدفوع' }}
                            </span>
                        </div>

                        <div class="card-offer-type">
                            @if($estate->offer_type === 'price')
                                💰 {{ number_format($estate->service_price, 0) }} ريال
                            @else
                                🏷️ خصم {{ $estate->discount }}%
                            @endif
                        </div>
                    </div>

                    {{-- Card Body --}}
                    <div class="card-body-inner">
                        <div class="card-offer-title">
                            <span>{{ $estate->title }}</span>
                            <div class="card-arrow">
                                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path d="M15 19l-7-7 7-7"/>
                                </svg>
                            </div>
                        </div>

                        <div class="card-service-name">
                            <svg fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M6 6V5a3 3 0 013-3h2a3 3 0 013 3v1h2a2 2 0 012 2v3.57A22.952 22.952 0 0110 13a22.95 22.95 0 01-8-1.43V8a2 2 0 012-2h2zm2-1a1 1 0 011-1h2a1 1 0 011 1v1H8V5zm1 5a1 1 0 011-1h.01a1 1 0 110 2H10a1 1 0 01-1-1z" clip-rule="evenodd"/></svg>
                            {{ $estate->serviceType?->name }}
                        </div>

                        <div class="card-tags">
                            @foreach($estate->categories->take(2) as $cat)
                                <span class="card-tag">{{ $cat->name_ar }}</span>
                            @endforeach
                            @foreach($estate->zones->take(2) as $zone)
                                <span class="card-tag zone">{{ $zone->name_ar }}</span>
                            @endforeach
                            @if($estate->categories->count() + $estate->zones->count() > 4)
                                <span class="card-tag" style="background:#f1f5f9;border-color:#e2e8f0;color:#64748b;">
                                    +{{ ($estate->categories->count() + $estate->zones->count()) - 4 }}
                                </span>
                            @endif
                        </div>

                        <div class="card-meta">
                            <div class="card-plan">
                                <svg fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                                {{ $planName }}
                            </div>
                            <div class="card-expiry">
                                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                </svg>
                                {{ $estate->expiry_date ?? '—' }}
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    @endif

</div>

{{-- ══ DETAIL MODAL ══════════════════════════════════════════════ --}}
<div class="detail-overlay" id="detail-overlay" onclick="closeOnBackdrop(event)">
    <div class="detail-sheet" id="detail-sheet">
        <span class="sheet-handle"></span>

        {{-- Modal Image --}}
        <div class="modal-img-wrap">
            <img id="modal-img" src="" alt="">
            <div class="modal-img-gradient"></div>
            <div class="modal-img-badges" id="modal-img-badges"></div>
            <div class="modal-img-title">
                <h2 id="modal-title"></h2>
                <div class="modal-img-service" id="modal-service"></div>
            </div>
            <button class="modal-close" onclick="closeModal()">
                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                    <path d="M6 18L18 6M6 6l12 12"/>
                </svg>
            </button>
        </div>

        <div class="modal-body-inner">

            {{-- Info Grid --}}
            <div class="modal-section-title">تفاصيل العرض</div>
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-item-label">
                        <svg fill="currentColor" viewBox="0 0 20 20"><path d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z"/><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.077 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.077-2.354-1.253V5z" clip-rule="evenodd"/></svg>
                        نوع العرض / القيمة
                    </div>
                    <div class="info-item-val price-val" id="modal-offer-val">—</div>
                </div>
                <div class="info-item">
                    <div class="info-item-label">
                        <svg fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"/></svg>
                        تاريخ الانتهاء
                    </div>
                    <div class="info-item-val" id="modal-expiry">—</div>
                </div>
                <div class="info-item">
                    <div class="info-item-label">
                        <svg fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                        حالة الاشتراك
                    </div>
                    <div class="info-item-val" id="modal-sub-status">—</div>
                </div>
                <div class="info-item">
                    <div class="info-item-label">
                        <svg fill="currentColor" viewBox="0 0 20 20"><path d="M4 4a2 2 0 00-2 2v1h16V6a2 2 0 00-2-2H4z"/><path fill-rule="evenodd" d="M18 9H2v5a2 2 0 002 2h12a2 2 0 002-2V9zM4 13a1 1 0 011-1h1a1 1 0 110 2H5a1 1 0 01-1-1zm5-1a1 1 0 100 2h1a1 1 0 100-2H9z" clip-rule="evenodd"/></svg>
                        حالة الدفع
                    </div>
                    <div class="info-item-val" id="modal-pay-status">—</div>
                </div>
            </div>

            {{-- Plan --}}
            <div class="modal-section-title">الباقة المشتركة</div>
            <div class="plan-card-modal">
                <div class="plan-icon">
                    <svg fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                </div>
                <div class="plan-info">
                    <div class="plan-info-name" id="modal-plan-name">—</div>
                    <div class="plan-info-price">سعر الباقة الشهري</div>
                </div>
                <div style="text-align:left;">
                    <div class="plan-price-cur">ريال</div>
                    <div class="plan-price-big" id="modal-plan-price">0.00</div>
                </div>
            </div>

            {{-- Categories & Zones --}}
            <div class="modal-section-title">التغطية الجغرافية والعقارية</div>
            <div class="tags-section">
                <div class="tag-group-label">
                    <svg fill="currentColor" viewBox="0 0 20 20"><path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"/></svg>
                    أنواع العقار
                </div>
                <div class="tag-pills" id="modal-cats"></div>

                <div class="tag-group-label mt-3">
                    <svg fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd"/></svg>
                    المناطق
                </div>
                <div class="tag-pills" id="modal-zones"></div>
            </div>

            {{-- Actions --}}
            <div class="modal-actions">
                <a id="modal-view-btn" href="#" class="btn-modal-view">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                        <path d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                    </svg>
                    عرض التفاصيل
                </a>
                <a id="modal-pay-btn" href="#" class="btn-modal-pay" style="display:none;">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/>
                    </svg>
                    إكمال الدفع
                </a>
            </div>
        </div>
    </div>
</div>
@endsection

@push('script')
<script>
/* ══ MODAL ══════════════════════════════════════════ */
function openModal(d) {
    document.getElementById('modal-img').src = d.img;
    document.getElementById('modal-title').innerText   = d.title;
    document.getElementById('modal-expiry').innerText  = d.expiry || '—';
    document.getElementById('modal-plan-name').innerText  = d.planName;
    document.getElementById('modal-plan-price').innerText = d.planPrice;

    // service
    document.getElementById('modal-service').innerHTML =
        `<svg width="14" height="14" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M6 6V5a3 3 0 013-3h2a3 3 0 013 3v1h2a2 2 0 012 2v3.57A22.952 22.952 0 0110 13a22.95 22.95 0 01-8-1.43V8a2 2 0 012-2h2zm2-1a1 1 0 011-1h2a1 1 0 011 1v1H8V5zm1 5a1 1 0 011-1h.01a1 1 0 110 2H10a1 1 0 01-1-1z" clip-rule="evenodd"/></svg> ${d.service}`;

    // offer value
    const offerEl = document.getElementById('modal-offer-val');
    if (d.offerType === 'price') {
        offerEl.innerHTML = `<span style="font-size:13px;color:var(--muted);font-weight:600;">سعر</span> ${d.price} ريال`;
    } else {
        offerEl.innerHTML = `<span style="font-size:13px;color:var(--muted);font-weight:600;">خصم</span> ${d.discount}%`;
    }

    // statuses
    const subEl = document.getElementById('modal-sub-status');
    subEl.innerText = d.subStatus;
    subEl.className = 'info-item-val ' + (d.subCls === 'active' ? 'green-val' : d.subCls === 'expired' ? 'red-val' : '');

    const payEl = document.getElementById('modal-pay-status');
    payEl.innerText = d.payStatus;
    payEl.className = 'info-item-val ' + (d.paid ? 'green-val' : 'red-val');

    // badges
    const badgesEl = document.getElementById('modal-img-badges');
    badgesEl.innerHTML = `
        <span class="card-badge status-${d.subCls}">${d.subStatus}</span>
        <span class="card-badge ${d.paid ? 'pay-paid' : 'pay-unpaid'}">${d.payStatus}</span>
    `;

    // cats & zones
    const catsEl  = document.getElementById('modal-cats');
    const zonesEl = document.getElementById('modal-zones');
    catsEl.innerHTML  = d.categories.length  ? d.categories.map(c =>
        `<span class="tag-pill cat"><svg width="12" height="12" fill="currentColor" viewBox="0 0 20 20"><path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"/></svg>${c}</span>`
    ).join('') : '<span style="color:var(--muted);font-size:13px;">—</span>';
    zonesEl.innerHTML = d.zones.length ? d.zones.map(z =>
        `<span class="tag-pill zon"><svg width="12" height="12" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd"/></svg>${z}</span>`
    ).join('') : '<span style="color:var(--muted);font-size:13px;">—</span>';

    // actions
    document.getElementById('modal-view-btn').href = d.viewRoute;
    const payBtn = document.getElementById('modal-pay-btn');
    if (!d.paid) {
        payBtn.style.display = 'flex';
        payBtn.href = d.payRoute;
    } else {
        payBtn.style.display = 'none';
    }

    document.getElementById('detail-overlay').classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    document.getElementById('detail-overlay').classList.remove('open');
    document.body.style.overflow = '';
}

function closeOnBackdrop(e) {
    if (e.target === document.getElementById('detail-overlay')) closeModal();
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeModal();
});

/* ══ FILTER + SEARCH ════════════════════════════════ */
const cards = document.querySelectorAll('.offer-card');
let activeFilter = 'all';

document.querySelectorAll('.filter-chip').forEach(chip => {
    chip.addEventListener('click', function() {
        document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
        this.classList.add('active');
        activeFilter = this.dataset.filter;
        applyFilters();
    });
});

document.getElementById('search-input')?.addEventListener('input', applyFilters);

function applyFilters() {
    const query  = (document.getElementById('search-input')?.value || '').toLowerCase().trim();
    const filter = activeFilter;

    cards.forEach((card, i) => {
        const status  = card.dataset.status;
        const payment = card.dataset.payment;
        const text    = card.textContent.toLowerCase();

        let visible = true;
        if (filter === 'active'  && status  !== 'active') visible = false;
        if (filter === 'expired' && status  !== 'expired') visible = false;
        if (filter === 'unpaid'  && payment === 'paid')    visible = false;
        if (query && !text.includes(query)) visible = false;

        card.style.display = visible ? '' : 'none';
        if (visible) card.style.animationDelay = (i * 0.04) + 's';
    });
}
</script>
@endpush